from django.db import models

class Currencies(models.Model):
    IDname = models.IntegerField("idname")
    Code = models.CharField("Код валюты", max_length=200)
    Fullname = models.CharField("Имя валюты", max_length=200)
    sign = models.CharField("Символ валюты", max_length=25)
